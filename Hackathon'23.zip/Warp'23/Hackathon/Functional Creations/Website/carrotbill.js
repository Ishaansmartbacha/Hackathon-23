x = prompt("What is the quantity of material you are buying? X6")
document.write("  Your Bill is : ₹", x*75)