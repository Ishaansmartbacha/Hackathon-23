x = prompt("What quantity of Tomatoes are you buying? X1")
document.write("Your bill is : ", x*150)