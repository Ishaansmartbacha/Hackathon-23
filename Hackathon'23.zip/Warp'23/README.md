This project is made by Ishaan Kumar and Aadyam Devgan There are 2
components:- Website and App

The main file of the website is \"index.html\"
The main file of the app is \"server.java"\

Sorry for the inconvienience with the .java file, please open it in VS CODE or any other extention as it wasn't changing into .exe file

Thank You

Credits

Ishaan Kumar - Website 
Aadyam Devgan - App
